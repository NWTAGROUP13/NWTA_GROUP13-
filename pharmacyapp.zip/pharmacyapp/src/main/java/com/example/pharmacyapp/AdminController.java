package com.example.pharmacyapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class AdminController {
    @FXML
    private TextField adminID;

    @FXML
    private PasswordField adminPassword;

    @FXML
    private Button loginButton,backButton;

    @FXML
    private Label noticeLabel;
    public void loginButtonOnAction(ActionEvent event) {
        authentication();
    }

    public void authentication(){
        DatabaseConnection connectNow= new DatabaseConnection();
        Connection connectDB=connectNow.getConnection();

        String verifyLogin= "SELECT count(1) FROM adminaccount WHERE AdminID='" + adminID.getText() + "' AND Password='" +adminPassword.getText()+ "'";

        try{
            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(verifyLogin);

            while(queryResult.next()){
                if(queryResult.getInt(1)==1){
                    BorderPane borderpane =  FXMLLoader.load(getClass().getResource("register.fxml"));
                    rootborderpane.getChildren().setAll(borderpane);
                }
                else{
                    noticeLabel.setText("Wrong Login, Retry");
                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    @FXML
    private BorderPane rootborderpane;
    public void backButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }
}
