package com.example.pharmacyapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

public class SalesController {

    @FXML
    private TextField productID,productName,quantity,price;

    @FXML
    private Button backButton,submitButton;

    @FXML
    private Label calLabel;

    @FXML
    private BorderPane rootborderpane;

    public void backButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("dashboard.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }

    public void sales(){
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String proID =productID.getText();
        String proName= productName.getText();
        Double quantityText= Double.valueOf(quantity.getText());
        Double priceText= Double.valueOf(price.getText());

        Double Total = quantityText * priceText;

        String insertFields= "INSERT INTO sales(productID,productName,quantity,price) VALUES('";
        String insertValues= proID+"','"+proName+"','"+quantityText+"','"+priceText+"')";
        String insertToRegister= insertFields+insertValues;

        try{
            Statement statement = connectDB.createStatement();
            statement.executeUpdate(insertToRegister);
            calLabel.setText(String.valueOf(Total));

        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }

    }

    public void submitButtonOnAction(ActionEvent event){
        sales();
    }

    public void addButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("sales.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }
}
