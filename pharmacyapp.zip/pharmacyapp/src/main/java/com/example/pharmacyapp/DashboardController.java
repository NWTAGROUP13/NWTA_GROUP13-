package com.example.pharmacyapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;

import java.io.IOException;

public class DashboardController {

    @FXML
    private Button addButton,salesButton,logoutButton,categoryButton;

    @FXML
    private BorderPane rootborderpane;
    public void addButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("product.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }

    public void salesButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("sales.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }

    public void logoutButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }

    public void categoryButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("category.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }
}
