package com.example.pharmacyapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

public class RegisterController {

    @FXML
    private TextField name,staffID,Password,confirmPassword;

    @FXML
    private Button signupButton,loginButton;

    @FXML
    private BorderPane rootborderpane;

    @FXML
    private Label noticeLabel;
    public void signupButtonOnAction(ActionEvent event) {
        registerStaff();

    }

    public void registerStaff(){
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            String nameText =name.getText();
            String staffIDText= staffID.getText();
            String passwordText= Password.getText();

        String insertFields= "INSERT INTO account(FullName,StaffID,Password) VALUES('";
        String insertValues= nameText+"','"+staffIDText+"','"+passwordText+"')";
        String insertToRegister= insertFields+insertValues;

        try{
            Statement statement = connectDB.createStatement();
            statement.executeUpdate(insertToRegister);
            BorderPane borderpane =  FXMLLoader.load(getClass().getResource("dashboard.fxml"));
            rootborderpane.getChildren().setAll(borderpane);
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }

    }

    public void loginButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }
}
