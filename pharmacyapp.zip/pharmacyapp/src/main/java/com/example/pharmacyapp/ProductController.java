package com.example.pharmacyapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;
import java.time.format.DateTimeFormatter;

public class ProductController {

    @FXML
    private Button addButton,backButtonOnAction;

    @FXML
    private DatePicker datep;

    @FXML
    private TextField productID,productName,productQuantity,unitCost,bulkCost,unitSell,bulkSell,supplierName,companyName,contact;

    @FXML
    private BorderPane rootborderpane;


    public void addButtonOnAction(ActionEvent event) {
        addProduct();
    }

    public void addProduct(){
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String prodID = productID.getText();
        String prodName= productName.getText();
        String dateText= datep.getValue().format(DateTimeFormatter.ofPattern("yy-MM-dd"));
        String prodQ= productQuantity.getText();
        String uCost= unitCost.getText();
        String bCost= bulkCost.getText();
        String uSell= unitSell.getText();
        String bSell= bulkSell.getText();
        String sName= supplierName.getText();
        String cName= companyName.getText();
        String con= contact.getText();

        String insertFields= "INSERT INTO product(productID,productName,date,productQuantity,unitCost,bulkCost,unitSell,bulkSell,supplierName,companyName,contact) VALUES('";
        String insertValues= prodID+"','"+prodName+"','"+dateText+"','"+prodQ+"','"+uCost+"','"+bCost+"','"+uSell+"','"+bSell+"','"+sName+"','"+cName+"','"+con+"')";
        String insertToRegister= insertFields+insertValues;

        try{
            Statement statement = connectDB.createStatement();
            statement.executeUpdate(insertToRegister);
            BorderPane borderpane =  FXMLLoader.load(getClass().getResource("product.fxml"));
            rootborderpane.getChildren().setAll(borderpane);
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void backButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("dashboard.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }
}
