package com.example.pharmacyapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class HelloController implements initializable{
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }
    @FXML
    private TextField userText;

    @FXML
    private PasswordField userPassword;

    @FXML
    private Button loginButton,closeButton,signupButton;

    @FXML
    private BorderPane rootborderpane;

    @FXML
    private Label noticeLabel;

    public void loginButtonOnAction(ActionEvent event) {
        authentication();
    }


    public void authentication(){
        DatabaseConnection connectNow= new DatabaseConnection();
        Connection connectDB=connectNow.getConnection();

        String verifyLogin= "SELECT count(1) FROM account WHERE StaffID='" + userText.getText() + "' AND Password='" +userPassword.getText()+ "'";

        try{
            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(verifyLogin);

            while(queryResult.next()){
                if(queryResult.getInt(1)==1){
                    BorderPane borderpane =  FXMLLoader.load(getClass().getResource("dashboard.fxml"));
                    rootborderpane.getChildren().setAll(borderpane);
                }
                else{
                    noticeLabel.setText("Wrong Login, Retry");
                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
    public void closeButtonOnAction(ActionEvent event) {
        Stage stage=(Stage) closeButton.getScene().getWindow();
        stage.close();
    }


    public void signupButtonOnAction(ActionEvent event) throws IOException {
        BorderPane borderpane =  FXMLLoader.load(getClass().getResource("admin.fxml"));
        rootborderpane.getChildren().setAll(borderpane);
    }
}